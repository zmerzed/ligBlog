#logo component

When a user click it, the page will always transfer to the index page.


#hamburger component

When a user click it, the nav menu will always be opened.
Please check index-nav.md about the nav menu.


#card components

+ When user click them, the page will transfer to the each article page.
+ The index page has 5 card components at maximum. (The archive page is also same)
+ The whole of the card component is clickable.


#button component

When a user click it, the page will transfer to the archive page.


#page top

When a user click it, the page will always scroll up to the top.