+ When a user clicks the button "New Article", the page will be transfered to the admin-post page and a use can post.
+ Each of posts is clickable and it has the link to the admin-post page.