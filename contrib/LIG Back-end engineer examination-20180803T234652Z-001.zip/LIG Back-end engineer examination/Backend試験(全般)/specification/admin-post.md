+ The eye catch image is the input module for uploading eye catch image.
+ The title is the input module for inputing a title of an article.
+ The contents is the input module for inputing texts of an article.
+ Only plane texts are available in the title & the contents.
+ If input modules has already had values, the user can edit them.
+ When the user clicks the submit button and all of input modules has values, the article will be posted.
+ When the user clicks the submit button and all of input modules has no values, the error message "Error" is just shown above the submit button.
+ The back button has the link to the admin-list page.