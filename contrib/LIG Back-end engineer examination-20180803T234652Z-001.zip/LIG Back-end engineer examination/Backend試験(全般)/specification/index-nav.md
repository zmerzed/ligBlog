#hamburger component

When the nav menu is opened, it is changed to the close style like "x".
And a user clicks it with the close style, the nav menu will be closed.


#menu

+ TOP ... When a user click it, the page will transfer to the index page.
+ Facebook ... When a user click it, the page will transfer to "https://www.facebook.com/facebook/". It has the attribute "target blank".
+ Twitter ... When a user click it, the page will transfer to "https://twitter.com/twitter". It has the attribute "target blank".