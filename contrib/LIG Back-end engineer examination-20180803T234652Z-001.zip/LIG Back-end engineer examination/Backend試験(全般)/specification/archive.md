#headline component

It has a molecule & a denominator.
A molecule means the number of the current page.
A denominator means the amount of the total pages.


#pagination component

+ When a user is in the start of page, the previous arrow button is not available, and its color is changed to gray.
+ When a user is in the end of page, the next arrow button is not available, and its color is changed to gray.