+ Please make administrator account with ID & password.
+ You can only make one administrator account.
+ You don't need make the functionality that we can edit the account of ID & password.
+ If the user input uncorrect values, this error message "Error" will just be shown above the loguin button.