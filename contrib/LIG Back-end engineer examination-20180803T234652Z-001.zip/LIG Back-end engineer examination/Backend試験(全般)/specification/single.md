#article content

The sentence input by a administrator is published here.
And it has only normal texts without styles (bold, italic, large size, list ... etc).


#button component

When a user click it, the page will transfer to the index page.